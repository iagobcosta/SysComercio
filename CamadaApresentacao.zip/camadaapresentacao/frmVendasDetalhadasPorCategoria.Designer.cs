﻿namespace CamadaApresentacao
{
    partial class frmVendasDetalhadasPorCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.sp_detalhes_venda_em_catao_de_debitoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsPrincipal = new CamadaApresentacao.dsPrincipal();
            this.sp_detalhes_venda_em_catao_de_creditoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sp_detalhes_vendaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sp_detalhes_venda_em_catao_de_debitoTableAdapter = new CamadaApresentacao.dsPrincipalTableAdapters.sp_detalhes_venda_em_catao_de_debitoTableAdapter();
            this.sp_detalhes_venda_em_catao_de_creditoTableAdapter = new CamadaApresentacao.dsPrincipalTableAdapters.sp_detalhes_venda_em_catao_de_creditoTableAdapter();
            this.sp_detalhes_vendaTableAdapter = new CamadaApresentacao.dsPrincipalTableAdapters.sp_detalhes_vendaTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.sp_detalhes_venda_em_catao_de_debitoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsPrincipal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_detalhes_venda_em_catao_de_creditoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_detalhes_vendaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // sp_detalhes_venda_em_catao_de_debitoBindingSource
            // 
            this.sp_detalhes_venda_em_catao_de_debitoBindingSource.DataMember = "sp_detalhes_venda_em_catao_de_debito";
            this.sp_detalhes_venda_em_catao_de_debitoBindingSource.DataSource = this.dsPrincipal;
            // 
            // dsPrincipal
            // 
            this.dsPrincipal.DataSetName = "dsPrincipal";
            this.dsPrincipal.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sp_detalhes_venda_em_catao_de_creditoBindingSource
            // 
            this.sp_detalhes_venda_em_catao_de_creditoBindingSource.DataMember = "sp_detalhes_venda_em_catao_de_credito";
            this.sp_detalhes_venda_em_catao_de_creditoBindingSource.DataSource = this.dsPrincipal;
            // 
            // sp_detalhes_vendaBindingSource
            // 
            this.sp_detalhes_vendaBindingSource.DataMember = "sp_detalhes_venda";
            this.sp_detalhes_vendaBindingSource.DataSource = this.dsPrincipal;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportViewer1.DocumentMapCollapsed = true;
            reportDataSource1.Name = "Debito";
            reportDataSource1.Value = this.sp_detalhes_venda_em_catao_de_debitoBindingSource;
            reportDataSource2.Name = "credito";
            reportDataSource2.Value = this.sp_detalhes_venda_em_catao_de_creditoBindingSource;
            reportDataSource3.Name = "dinheiro";
            reportDataSource3.Value = this.sp_detalhes_vendaBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "CamadaApresentacao.Relatorios.rptVendasEmDebito.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(734, 261);
            this.reportViewer1.TabIndex = 0;
            // 
            // sp_detalhes_venda_em_catao_de_debitoTableAdapter
            // 
            this.sp_detalhes_venda_em_catao_de_debitoTableAdapter.ClearBeforeFill = true;
            // 
            // sp_detalhes_venda_em_catao_de_creditoTableAdapter
            // 
            this.sp_detalhes_venda_em_catao_de_creditoTableAdapter.ClearBeforeFill = true;
            // 
            // sp_detalhes_vendaTableAdapter
            // 
            this.sp_detalhes_vendaTableAdapter.ClearBeforeFill = true;
            // 
            // frmVendasDetalhadasPorCategoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 261);
            this.Controls.Add(this.reportViewer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmVendasDetalhadasPorCategoria";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalhe das vendas";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmVendasDetalhadasPorCategoria_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sp_detalhes_venda_em_catao_de_debitoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsPrincipal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_detalhes_venda_em_catao_de_creditoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sp_detalhes_vendaBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource sp_detalhes_venda_em_catao_de_debitoBindingSource;
        private dsPrincipal dsPrincipal;
        private System.Windows.Forms.BindingSource sp_detalhes_venda_em_catao_de_creditoBindingSource;
        private System.Windows.Forms.BindingSource sp_detalhes_vendaBindingSource;
        private dsPrincipalTableAdapters.sp_detalhes_venda_em_catao_de_debitoTableAdapter sp_detalhes_venda_em_catao_de_debitoTableAdapter;
        private dsPrincipalTableAdapters.sp_detalhes_venda_em_catao_de_creditoTableAdapter sp_detalhes_venda_em_catao_de_creditoTableAdapter;
        private dsPrincipalTableAdapters.sp_detalhes_vendaTableAdapter sp_detalhes_vendaTableAdapter;
    }
}