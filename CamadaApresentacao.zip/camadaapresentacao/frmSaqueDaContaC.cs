﻿using CamadaNegocio;
using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Root.Reports;

namespace CamadaApresentacao
{
    public partial class frmSaqueDaContaC : Form
    {
        private string Nome;
        private string Sobrenome;
        public frmSaqueDaContaC(string nome, string sobrenome)
        {
            InitializeComponent();
            this.Nome = nome;
            this.Sobrenome = sobrenome;
           
        }

        //Mostrar mensagem de confirmação
        public void MensagemOk(string mensagem)
        {
            MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        //Mostrar mensagem de erro
        public void MensagemErro(string mensagem)
        {
            MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnSacar_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtNumeroDaConta.Text == string.Empty)
                {
                    MensagemErro("Preencha todos os campos");

                }
                else
                {
                    NContaLoja.saqueDContaCorrente(Convert.ToInt32(txtNumeroDaConta.Text), Convert.ToDecimal(txtValor.Text));
                    MensagemOk("Saque efetuado com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            DataTable dados1 = CamadaNegocio.NEmpresa.Mostrar();
            using (var doc = new PdfSharp.Pdf.PdfDocument())
            {
                var page = doc.AddPage();
                var graphics = PdfSharp.Drawing.XGraphics.FromPdfPage(page);
                var textFormatter = new PdfSharp.Drawing.Layout.XTextFormatter(graphics);
                var font = new PdfSharp.Drawing.XFont("Arial", 12);
                textFormatter.Alignment = PdfSharp.Drawing.Layout.XParagraphAlignment.Center;
                //escrevendo no arquivo
                try
                {
                    textFormatter.DrawString("         *SAQUE DA CONTA CORRENTE*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 30, page.Width-60, page.Height - 60));
                    textFormatter.DrawString(dados1.Rows[0][1].ToString() + " -- " + DateTime.Now.ToString(), font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 50, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Nome do Funcionário: " + this.Nome + "-" + this.Sobrenome, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 70, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Número da conta: " + txtNumeroDaConta.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 90, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Valor do depósito: R$" + txtValor.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 110, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Observação: " + txtdescricao.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 130, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("         *SAQUE DA CONTA CORRENTE*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 150, page.Width - 60, page.Height - 60));

                    
                    doc.Save("arquivo.pdf");
                    System.Diagnostics.Process.Start("arquivo.pdf");
                    MessageBox.Show("Arquivo Gerado com sucesso !", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao Gerar arquivo !!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void frmSaqueDaContaC_Load(object sender, EventArgs e)
        {
            DataTable Dados = CamadaNegocio.NContaLoja.Mostrar();
            this.lblSaldo.Text = Dados.Rows[0][3].ToString();
        }
    }
}
