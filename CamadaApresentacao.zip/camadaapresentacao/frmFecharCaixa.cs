﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace CamadaApresentacao
{
    public partial class frmFecharCaixa : Form
    {
        public frmFecharCaixa()
        {
            InitializeComponent();
        }
        private static frmFecharCaixa _Instancia;



        public static frmFecharCaixa GetInstancia()
        {
            if (_Instancia == null)
            {
                _Instancia = new frmFecharCaixa();
            }
            return _Instancia;
        }
         public void buscarID()
        {
            SqlConnection con = new SqlConnection(CamadaNegocio.NConexao.conexao1());
            con.Close();
            con.Open();

            SqlCommand cmd1 = new SqlCommand("SELECT * FROM  movimentacaoCaixa WHERE data_Abertura = '"+DateTime.Now.ToString("yyyy/MM/dd") +"'", con);
            SqlDataReader leitor = cmd1.ExecuteReader();
           
            string valor;
            string idCaixa;
            leitor.Read();           
            valor = leitor["valor_inicial"].ToString();
            idCaixa = leitor["id"].ToString();      
            lblValorDoCaixaInicial.Text = valor;
            txtID.Text = idCaixa;
            leitor.Close();
        }

        public void fecharCaixa(string valor)
        {
            SqlConnection con = new SqlConnection(CamadaNegocio.NConexao.conexao1());
            con.Close();
            SqlCommand cmd = new SqlCommand("UPDATE movimentacaoCaixa SET  ativo='0', saida = '"+valor+"' WHERE data_Abertura = '" + DateTime.Now.ToString("yyyy/MM/dd") + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            frmPrincipal.caixaAberto = false;
            con.Close();
            this.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {

               this.fecharCaixa(txtValorDoSaque.Text);
                MessageBox.Show("Fechamento do saque realizado com sucesso!", "ATENÇÂO", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar fechar o caixa!");
            }
            
        }

        private void frmFecharCaixa_FormClosed(object sender, FormClosedEventArgs e)
        {
            _Instancia = null;
        }

        private void frmFecharCaixa_Load(object sender, EventArgs e)
        {
            this.buscarID();
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {

                    SqlConnection con = new SqlConnection(CamadaNegocio.NConexao.conexao1());
                    con.Close();
                    SqlCommand cmd = new SqlCommand("UPDATE movimentacaoCaixa SET  ativo='0', saida = saida + @saida WHERE data_Abertura = '" + DateTime.Now.ToString("yyyy/MM/dd") + "'", con);
                    cmd.Parameters.AddWithValue("@saida", txtValorDoSaque.Text);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    frmPrincipal.caixaAberto = false;
                    con.Close();
                    this.Close();
                    frmVenda f = new frmVenda();
                    f.Close();




                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erro ao tentar fechar o caixa!");
                }

            }
        }
    }
}
