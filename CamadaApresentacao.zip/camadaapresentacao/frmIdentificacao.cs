﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmIdentificacao : Form
    {
        public frmIdentificacao()
        {
            InitializeComponent();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            DataTable Dados = CamadaNegocio.NFuncionario.Login(txtUsuario.Text, txtSenha.Text);
            if (Dados.Rows.Count == 0)
            {
                MessageBox.Show("O Usuário não Existe, tente novamente!", "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Hide();
                    
            }
        }

        private void frmIdentificacao_Load(object sender, EventArgs e)
        {
            this.txtUsuario.Focus();
        }

        

        private void frmIdentificacao_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btnConfirmar.PerformClick();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
