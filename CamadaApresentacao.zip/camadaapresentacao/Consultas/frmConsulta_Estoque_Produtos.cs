﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CamadaNegocio;

namespace CamadaApresentacao.Consultas
{
    public partial class frmConsulta_Estoque_Produtos : Form
    {
        public frmConsulta_Estoque_Produtos()
        {
            InitializeComponent();
        }


        //Ocultar as Colunas do Grid
        private void ocultarColunas()
        {
            this.dataLista1.Columns[0].Visible = false;
            this.dataLista1.Columns["Column1"].HeaderText = "Estoque Inicial";
            this.dataLista1.Columns["Column2"].HeaderText = "Estoque Atual";
            this.dataLista1.Columns["Quantidade_venda"].HeaderText = "Quantidade de Venda";

        }

        


        //Mostrar no Data Grid
        private void Mostrar()
        {
            this.dataLista1.DataSource = NProduto.EstoqueProduto();
            this.ocultarColunas();
            lblTotal.Text = "Total de Registros: " + Convert.ToString(dataLista1.Rows.Count);
        }

        private void frmConsulta_Estoque_Produtos_Load(object sender, EventArgs e)
        {
            this.Mostrar();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            frmEstoque frm = new frmEstoque();
            frm.ShowDialog();
        }

        private void dataLista1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            frmPrincipal frm = new frmPrincipal();
            
        }
    }
}
