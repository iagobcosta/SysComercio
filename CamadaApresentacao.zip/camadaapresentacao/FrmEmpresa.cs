﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CamadaNegocio;

namespace CamadaApresentacao
{
    
    public partial class FrmEmpresa : Form
    {
        
        
            private bool eNovo = false;
            private bool eEditar = false;
            private static FrmEmpresa _Instancia;
            public static FrmEmpresa GetInstancia()
            {
                if (_Instancia == null)
                {
                    _Instancia = new FrmEmpresa();
                }
                return _Instancia;
            }

            public FrmEmpresa()
            {
                InitializeComponent();
                this.ttMensagem.SetToolTip(this.txtRazao_social, "Insira o nome da Empresa");
            }



            //Mostrar mensagem de confirmação
            private void MensagemOk(string mensagem)
            {
                MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            //Mostrar mensagem de erro
            private void MensagemErro(string mensagem)
            {
                MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

          
            //Limpar Campos
            private void Limpar()
            {
                this.txtRazao_social.Text = string.Empty;
                this.txtEndereco.Text = string.Empty;
                this.txtBairro.Text = string.Empty;
                this.txtCidade.Text = string.Empty;
                this.txtIE.Text = string.Empty;
                this.txtCnpj.Text = string.Empty;
                this.txtTelefone.Text = string.Empty;
            this.txtNomeFantasia.Text = string.Empty;
            this.txtNumero.Text = string.Empty;
            this.txtCcf.Text = string.Empty;
            this.txtCoo.Text = string.Empty;
            this.txtEstado.Text = string.Empty;

        }


            //Habilitar os text box
            private void Habilitar(bool valor)
            {
                this.txtRazao_social.ReadOnly = !valor;
                this.txtEndereco.ReadOnly = !valor;
                this.txtBairro.ReadOnly = !valor;
                this.txtCidade.ReadOnly = !valor;
                this.txtIE.ReadOnly = !valor;
                this.txtCnpj.ReadOnly = !valor;
                this.txtTelefone.ReadOnly = !valor;
                this.txtNomeFantasia.ReadOnly = !valor;
                this.txtNumero.ReadOnly = !valor;
                this.txtCcf.ReadOnly = !valor;
                this.txtCoo.ReadOnly = !valor;
                this.txtEstado.ReadOnly = !valor;

        }


            //Habilitar os botoes
            private void botoes()
            {
                if (this.eNovo || this.eEditar)
                {
                    this.Habilitar(true);
                    this.btnNovo.Enabled = false;
                    this.btnSalvar.Enabled = true;
                    this.btnEditar.Enabled = false;
                    this.btnCancelar.Enabled = true;

                }
                else
                {
                    this.Habilitar(false);
                    this.btnNovo.Enabled = true;
                    this.btnSalvar.Enabled = false;
                    this.btnEditar.Enabled = true;
                    this.btnCancelar.Enabled = false;
                }

            }



            //Ocultar as Colunas do Grid
            private void ocultarColunas()
            {
                this.dataLista.Columns[0].Visible = false;
                this.dataLista.Columns[1].Visible = false;
            }


            //Mostrar no Data Grid
            private void Mostrar()
            {
                this.dataLista.DataSource = NEmpresa.Mostrar();
                this.ocultarColunas();
                lblTotal.Text = "Total de Registros: " + Convert.ToString(dataLista.Rows.Count);
            }



            //Buscar pelo Nome da Empresa
            private void BuscarNome()
            {
                this.dataLista.DataSource = NEmpresa.BuscarNome(this.txtBuscar.Text);

                this.ocultarColunas();
                lblTotal.Text = "Total de Registros: " + Convert.ToString(dataLista.Rows.Count);
            }


            //Buscar pelo Num Doc
            private void BuscarDocumento()
            {
                this.dataLista.DataSource = NEmpresa.BuscarCnpj(this.txtBuscar.Text);

                this.ocultarColunas();
                lblTotal.Text = "Total de Registros: " + Convert.ToString(dataLista.Rows.Count);
            }

            private void FrmEmpresa_Load(object sender, EventArgs e)
        {
            this.Mostrar();
            this.Habilitar(false);
            this.botoes();
            this.txtId.Enabled = false;
            this.cbBusca.SelectedIndex = 0;
            this.mudarNomeDaColuna();




        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (cbBusca.Text.Equals("Nome"))
            {
                this.BuscarNome();
            }
            else if (cbBusca.Text.Equals("Cnpj"))
            {
                this.BuscarDocumento();
            }

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (cbBusca.Text.Equals("Nome"))
            {
                this.BuscarNome();
            }
            else if (cbBusca.Text.Equals("Cnpj"))
            {
                this.BuscarDocumento();
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            this.eNovo = true;
            this.eEditar = false;
            this.botoes();
            this.Limpar();
            this.Habilitar(true);
            this.txtRazao_social.Focus();
            this.txtId.Enabled = false;
        }
        

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                string resp = "";
                if (this.txtRazao_social.Text == string.Empty)
                {
                    MensagemErro("Preencha todos os campos");
                    errorIcone.SetError(txtRazao_social, "Insira o nome da Empresa");

                }
                else
                {
                    if (this.eNovo)
                    {
                        resp = NEmpresa.Inserir(this.txtRazao_social.Text.Trim().ToUpper(), this.txtEndereco.Text, this.txtBairro.Text, this.txtCidade.Text.Trim().ToUpper(), this.txtIE.Text, this.txtCnpj.Text, this.txtTelefone.Text, this.txtNomeFantasia.Text,this.txtNumero.Text,this.txtCcf.Text,this.txtCoo.Text,this.txtEstado.Text);
                    }
                    else
                    {
                        resp = NEmpresa.Editar(Convert.ToInt32(this.txtId.Text),
                            this.txtRazao_social.Text.Trim().ToUpper(), this.txtEndereco.Text, this.txtBairro.Text, this.txtCidade.Text.Trim().ToUpper(), this.txtIE.Text, this.txtCnpj.Text, this.txtTelefone.Text, this.txtNomeFantasia.Text, this.txtNumero.Text, this.txtCcf.Text, this.txtCoo.Text, this.txtEstado.Text);
                    }

                    if (resp.Equals("OK"))
                    {
                        if (this.eNovo)
                        {
                            this.MensagemOk("Registro salvo com sucesso");
                        }
                        else
                        {
                            this.MensagemOk("Registro editado com sucesso");
                        }
                    }
                    else
                    {
                        this.MensagemErro(resp);
                    }

                    this.eNovo = false;
                    this.eEditar = false;
                    this.botoes();
                    this.Limpar();
                    this.Mostrar();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        

        private void dataLista_DoubleClick(object sender, EventArgs e)
        {
            this.txtId.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["ID"].Value);
            this.txtRazao_social.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["razao_social"].Value);
            this.txtEndereco.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["endreco"].Value);
            this.txtBairro.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["bairro"].Value);
            this.txtCidade.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["cidade"].Value);
            this.txtIE.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["IE"].Value);
            this.txtCnpj.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["CNPJ"].Value);
            this.txtTelefone.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["telefone"].Value);
            this.txtNomeFantasia.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["nome_fantasia"].Value);
            this.txtNumero.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["numero"].Value);
            this.txtCcf.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["ccf"].Value);
            this.txtCoo.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["coo"].Value);
            this.txtEstado.Text = Convert.ToString(this.dataLista.CurrentRow.Cells["estado"].Value);
            this.tabControl1.SelectedIndex = 1;
        }
        private void mudarNomeDaColuna()
        {
            dataLista.Columns["ID"].HeaderText = "Código";
            dataLista.Columns["razao_social"].HeaderText = "Razão social";
            dataLista.Columns["endreco"].HeaderText = "Endereço";
            dataLista.Columns["bairro"].HeaderText = "Bairro";
            dataLista.Columns["cidade"].HeaderText = "Cidade";
            dataLista.Columns["telefone"].HeaderText = "Telefone";
            dataLista.Columns["nome_fantasia"].HeaderText = "Nome Fantasia";
            dataLista.Columns["numero"].HeaderText = "Número";
            dataLista.Columns["estado"].HeaderText = "Estado";
                     
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (this.txtId.Text.Equals(""))
            {
                this.MensagemErro("Selecione um registro para Editar");
            }
            else
            {
                this.eEditar = true;
                this.botoes();
                this.Habilitar(true);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.eNovo = false;
            this.eEditar = false;
            this.botoes();
            this.Habilitar(false);
            this.Limpar();
        }

        private void chkDeletar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDeletar.Checked)
            {
                this.dataLista.Columns[0].Visible = true;
            }
            else
            {
                this.dataLista.Columns[0].Visible = false;
            }
        }

        private void dataLista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataLista.Columns["Deletar"].Index)
            {
                DataGridViewCheckBoxCell chkDeletar = (DataGridViewCheckBoxCell)dataLista.Rows[e.RowIndex].Cells["Deletar"];
                chkDeletar.Value = !Convert.ToBoolean(chkDeletar.Value);
            }
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult Opcao;
                Opcao = MessageBox.Show("Realmente Deseja apagar os Registros", "Sistema Comércio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (Opcao == DialogResult.OK)
                {
                    string Codigo;
                    string Resp = "";

                    foreach (DataGridViewRow row in dataLista.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            Codigo = Convert.ToString(row.Cells[1].Value);
                            Resp = NEmpresa.Excluir(Convert.ToInt32(Codigo));

                            if (Resp.Equals("OK"))
                            {
                                this.MensagemOk("Registro excluido com sucesso");

                            }
                            else
                            {
                                this.MensagemErro(Resp);
                            }
                        }
                    }
                    this.Mostrar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void txtBuscar_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            frmPrincipal frm = new frmPrincipal();
           
        }
    }
}
