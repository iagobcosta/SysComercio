﻿using System;
using System.Windows.Forms;
using CamadaNegocio;



namespace CamadaApresentacao
{
    
    public partial class frmReceberPagamento : Form 
    {
       
        
        public frmReceberPagamento()
        {
            InitializeComponent();
        }

        public frmReceberPagamento(string valor)
        {
            InitializeComponent();
            this.txtValorTotal.Text = Convert.ToDecimal(valor.ToString()).ToString("0.00");
            txtValorRecebido.Focus();
            
        }

         private void txtTroco_KeyPress(object sender, KeyPressEventArgs e)
         {

             if (txtValorRecebido.Text == string.Empty)
             {
                 MessageBox.Show("Nao existe entrada de caixa"); return;
             }
             else
             {

                 decimal res = 0;
                 decimal positivo = 0;
                 decimal negativo = 0;
                 positivo = Convert.ToDecimal( txtValorRecebido.Text);
                 negativo = Convert.ToDecimal(txtValorTotal.Text);
                 res = positivo - negativo;
                 txtTroco.Text = Convert.ToString(res);
             }
         }

        

        private void frmReceberPagamento_Load(object sender, EventArgs e)
        {
            this.txtValorRecebido.Focus();
        }
        
        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            frmVenda f = new frmVenda();
            Hide();
        }

        private void txtValorTotal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtValorRecebido.Focus();
            }
        }

        private void txtValorRecebido_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtTroco.Focus();
            }
        }

        private void txtTroco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnFinalizar.Focus();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            
        }

        public void btnCancelar_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
