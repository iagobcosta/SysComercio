﻿using CamadaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmContaLoja : Form
    {
        public frmContaLoja()
        {
            InitializeComponent();
        }
        public string saldo { get; set; }
        

        //Ocultar as Colunas do Grid
        private void ocultarColunas()
        {
            this.dataListaConta.Columns[0].Visible = false;
            this.dataListaConta.Columns[1].Visible = false;
            //this.dataListaConta.Columns[2].Visible = false;
            
        }

        //Mostrar no Data Grid
        private void Mostrar()
        {
            this.dataListaConta.DataSource = NContaLoja.Mostrar();
            this.ocultarColunas();
        }        

        private void frmContaLoja_Load(object sender, EventArgs e)
        {
            this.Mostrar();
        }
        

       

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
        }

       

       

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            this.Mostrar();
        }

        
    }
}
