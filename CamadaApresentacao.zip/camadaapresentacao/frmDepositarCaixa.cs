﻿using System;
using System.Text;
using System.Windows.Forms;
using CamadaNegocio;
using System.IO;
using System.Data;

namespace CamadaApresentacao
{
    public partial class frmDepositarCaixa : Form
    {
        private string Nome;
        private string Sobrenome;
        public frmDepositarCaixa(string nome,string sobrenome)
        {
            InitializeComponent();
            this.Nome =  nome.ToString();
            this.Sobrenome = sobrenome.ToString();
        }
        
        
        private void frmDepositarCaixa_Load(object sender, EventArgs e)
        {
            
            

        }

        private void depositarCaixa()
        {

        }

        private void btnDepositar_Click(object sender, EventArgs e)
        {
            try
            {

                NContaLoja.inserirCaixa(Convert.ToInt32(txtCodigo.Text), Convert.ToDecimal(txtValor.Text));
                MessageBox.Show("Depositado com sucesso!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            DataTable dados1 = CamadaNegocio.NEmpresa.Mostrar();
            using (var doc = new PdfSharp.Pdf.PdfDocument())
            {
                var page = doc.AddPage();
                var graphics = PdfSharp.Drawing.XGraphics.FromPdfPage(page);
                var textFormatter = new PdfSharp.Drawing.Layout.XTextFormatter(graphics);
                var font = new PdfSharp.Drawing.XFont("Arial", 12);
                textFormatter.Alignment = PdfSharp.Drawing.Layout.XParagraphAlignment.Center;
                //escrevendo no arquivo
                try
                {
                    textFormatter.DrawString("         *DEPÓSITO CAIXA*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 30, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString(dados1.Rows[0][1].ToString() + " -- " + DateTime.Now.ToString(), font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 50, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Nome do Funcionário: " + this.Nome + "-" + this.Sobrenome, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 70, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Número da conta: " + txtCodigo.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 90, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Valor do depósito: R$" + txtValor.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 110, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("Observação: " + txtObservacoes.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 130, page.Width - 60, page.Height - 60));
                    textFormatter.DrawString("         *DEPÓSITO CAIXA*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 150, page.Width - 60, page.Height - 60));


                    doc.Save("arquivo.pdf");
                    System.Diagnostics.Process.Start("arquivo.pdf");
                    MessageBox.Show("Arquivo Gerado com sucesso !", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao Gerar arquivo !!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
