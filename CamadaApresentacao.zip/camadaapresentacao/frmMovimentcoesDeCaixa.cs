﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using CamadaNegocio;

namespace CamadaApresentacao
{
    public partial class frmMovimentcoesDeCaixa : Form
    {
        private int idDoCaixa;
        
        public frmMovimentcoesDeCaixa()
        {
            InitializeComponent();
        }
        
        public void buscarCaixaAberto()
        {
            this.dtCaixas.DataSource = NMovimentacaoDeCaixa.BuscarCaixaAbero(this.dtInicial.Value.ToString("yyyy/MM/dd"), this.dtFinal.Value.ToString("yyyy/MM/dd"));
        }

        public void buscarCaixaFechado()
        {
            this.dtCaixas.DataSource = NMovimentacaoDeCaixa.BuscarCaixafechado(this.dtInicial.Value.ToString("yyyy/MM/dd"), this.dtFinal.Value.ToString("yyyy/MM/dd"));
        }


        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (rbAberto.Checked)
            {
                buscarCaixaAberto();
            }
            if(rbFechado.Checked)
            {
                buscarCaixaFechado();
            }
        }

        private void frmMovimentcoesDeCaixa_Load(object sender, EventArgs e)
        {
            dtCaixas.DataSource = NMovimentacaoDeCaixa.mostrarCaixas();
        }

        private void btnFecharCaixa_Click(object sender, EventArgs e)
        {
            try
            {
                this.idDoCaixa = Convert.ToInt32(this.dtCaixas.CurrentRow.Cells["id"].Value);

                if (MessageBox.Show("Deseja realmente fechar esse caixa em aberto!", "ATENÇÃO", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
                {
                    SqlConnection con = new SqlConnection(NConexao.conexao1());
                    con.Close();
                    SqlCommand cmd = new SqlCommand("UPDATE movimentacaoCaixa SET  ativo='0'  WHERE id = '" + idDoCaixa + "'", con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                MessageBox.Show("Caixa fechado com sucesso!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Não foi possível fechar o caixa!", ex.Message);
            }
        }
    }
}
