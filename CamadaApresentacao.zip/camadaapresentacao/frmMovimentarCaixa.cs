﻿using CamadaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CamadaNegocio;
using System.Data.SqlClient;
using CamadaApresentacao;

namespace CamadaApresentacao
{
    public partial class frmMovimentarCaixa : Form
    {
        public string IdFuncionario = "";
            
        public frmMovimentarCaixa()
        {
            InitializeComponent();
        }

        private static frmMovimentarCaixa _Instancia;



        public static frmMovimentarCaixa GetInstancia()
        {
            if (_Instancia == null)
            {
                _Instancia = new frmMovimentarCaixa();
            }
            return _Instancia;
        }

        //Mostrar mensagem de confirmação
        public void MensagemOk(string mensagem)
        {
            MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        //Mostrar mensagem de erro
        public void MensagemErro(string mensagem)
        {
            MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void frmMovimentarCaixa_Load(object sender, EventArgs e)
        {
            this.carregarUsuario();
        }
        string id;
        public  void buscarIdFuncionario()
        {
            
            SqlConnection con = new SqlConnection(NConexao.conexao1());
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM movimentacaoCaixa  WHERE data_Abertura = '" + DateTime.Now.ToString("yyyy/MM/dd") + "'", con);
            SqlDataReader leitor = cmd.ExecuteReader();

            
            leitor.Read();
            id = leitor["id_funcionario"].ToString();
            leitor.Close();
                
                con.Close();
            
           
        }

        public void carregarUsuario()
        {
             
            try
            {
                SqlConnection con = new SqlConnection(NConexao.conexao1());
                con.Close();
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT usuario FROM  funcionario", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cbUsuarios.DataSource = null;
                cbUsuarios.DataSource = dt;
                cbUsuarios.DisplayMember = "usuario";
                con.Close();


            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro a carregar usuarios!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            frmPrincipal.AbrirCaixa(cbUsuarios.Text, txtSenha.Text,txtValor.Text);
            this.buscarIdFuncionario();
            if(frmPrincipal.caixaAberto == true)
            {
               
                frmVenda frm = frmVenda.GetInstancia();
                frm.MdiParent = CamadaApresentacao.frmPrincipal.ActiveForm;
                frm.Show();
                frm.idfuncionario = Convert.ToInt32(id);
                this.Close();

            }
            else
            {
                MessageBox.Show("erro ao entrar na tela de vendas!");
            }
           
         
        }

        private void frmMovimentarCaixa_FormClosed(object sender, FormClosedEventArgs e)
        {
            _Instancia = null;
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                frmPrincipal.AbrirCaixa(cbUsuarios.Text, txtSenha.Text,  txtValor.Text);
                this.buscarIdFuncionario();
                if (frmPrincipal.caixaAberto == true)
                {

                    frmVenda frm = frmVenda.GetInstancia();
                    frm.MdiParent = CamadaApresentacao.frmPrincipal.ActiveForm;
                    frm.Show();
                    frm.idfuncionario = Convert.ToInt32(id);
                    this.Close();

                }
                else
                {
                    MessageBox.Show("erro ao entrar na tela de vendas!");
                }
            }
        }
    }
}
