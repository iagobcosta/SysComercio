﻿namespace CamadaApresentacao
{
    partial class frmFecharCaixa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblValorDoCaixaInicial = new System.Windows.Forms.Label();
            this.txtValorDoSaque = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(93, 167);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Confirmar (Enter)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button1_KeyDown);
            this.button1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.button1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Saldo do caixa inicial:";
            // 
            // lblValorDoCaixaInicial
            // 
            this.lblValorDoCaixaInicial.AutoSize = true;
            this.lblValorDoCaixaInicial.Location = new System.Drawing.Point(171, 34);
            this.lblValorDoCaixaInicial.Name = "lblValorDoCaixaInicial";
            this.lblValorDoCaixaInicial.Size = new System.Drawing.Size(35, 13);
            this.lblValorDoCaixaInicial.TabIndex = 2;
            this.lblValorDoCaixaInicial.Text = "label2";
            // 
            // txtValorDoSaque
            // 
            this.txtValorDoSaque.Location = new System.Drawing.Point(106, 90);
            this.txtValorDoSaque.Name = "txtValorDoSaque";
            this.txtValorDoSaque.Size = new System.Drawing.Size(100, 20);
            this.txtValorDoSaque.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Saque:";
            // 
            // txtID
            // 
            this.txtID.AutoSize = true;
            this.txtID.Location = new System.Drawing.Point(209, 9);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(35, 13);
            this.txtID.TabIndex = 6;
            this.txtID.Text = "label2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(176, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Caixa:";
            // 
            // frmFecharCaixa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(288, 261);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtValorDoSaque);
            this.Controls.Add(this.lblValorDoCaixaInicial);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFecharCaixa";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fechamento de caixa";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmFecharCaixa_FormClosed);
            this.Load += new System.EventHandler(this.frmFecharCaixa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblValorDoCaixaInicial;
        private System.Windows.Forms.TextBox txtValorDoSaque;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label txtID;
        private System.Windows.Forms.Label label4;
    }
}