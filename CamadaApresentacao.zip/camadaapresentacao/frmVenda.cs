﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using CamadaNegocio;
using System.Data.SqlClient;

namespace CamadaApresentacao
{
    public partial class frmVenda : Form
    {
        public string tipoPagamento;
        public int idfuncionario;

        public bool eNovo;
        public DataTable dtDetalhe;

        public decimal totalPago = 0;
        private static frmVenda _Instancia;

        

        public static frmVenda GetInstancia()
        {
            if (_Instancia == null)
            {
                _Instancia = new frmVenda();
            }
            return _Instancia;
        }


        public frmVenda()
        {
            InitializeComponent();
            this.ttMensagem.SetToolTip(this.btnBuscarCliente, "Busque o Cliente");
            this.ttMensagem.SetToolTip(this.btnBuscarProduto, "Busque o Produto");
            this.txtIdCliente.Enabled = false;
            this.txtIdProduto.Enabled = false;
            this.txtCliente.Enabled = false;
            this.txtProduto.Enabled = false;
            this.txtCorrelativo.Enabled = false;
            

        }



        //Mostrar mensagem de confirmação
        public void MensagemOk(string mensagem)
        {
            MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        //Mostrar mensagem de erro
        public void MensagemErro(string mensagem)
        {
            MessageBox.Show(mensagem, "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }



        //Limpar Campos
        public void Limpar()
        {
            this.txtIdCliente.Text = string.Empty;
            this.txtCliente.Text = string.Empty;
            this.txtSerie.Text = string.Empty;
            this.txtCorrelativo.Text = string.Empty;
            this.txtImposto.Text = string.Empty;

            this.lblTotalPagar.Text = Convert.ToInt32(0).ToString();
            this.CriarTabela();

        }

        public void LimparDetalhes()
        {
            this.txtIdProduto.Text = string.Empty;
            this.txtProduto.Text = string.Empty;
            this.txtEstoqueAtual.Text = string.Empty;
            this.txtPrecoVenda.Text = string.Empty;
            this.txtPrecoCompra.Text = string.Empty;
            this.txtDesconto.Text = "0";
            this.txtquantidade.Text = string.Empty;
        }


        //Habilitar os text box
        private void Habilitar(bool valor)
        {
            this.dtData.Enabled = valor;
            this.dtVencimento.Enabled = valor;

            this.txtSerie.ReadOnly = !valor;
            this.txtCorrelativo.ReadOnly = !valor;
            this.txtImposto.ReadOnly = !valor;
            this.txtDesconto.ReadOnly = !valor;
            this.txtPrecoCompra.ReadOnly = !valor;
            this.txtPrecoVenda.ReadOnly = !valor;
            this.txtEstoqueAtual.ReadOnly = !valor;
            this.txtquantidade.ReadOnly = !valor;
            this.cbComprovante.Enabled = valor;
            this.cbTipoPagamento.Enabled = valor;


            this.btnAdd.Enabled = valor;
            this.btnRemover.Enabled = valor;
            this.btnBuscarCliente.Enabled = valor;
            this.btnBuscarProduto.Enabled = valor;
        }


        //Habilitar os botoes
        public void botoes()
        {
            if (this.eNovo)
            {
                this.Habilitar(true);
                this.btnNovo.Enabled = false;
                this.btnSalvar.Enabled = true;
                this.btnBuscar.Enabled = true;
                this.btnCancelar.Enabled = true;
                this.btnBuscarCliente.Enabled = true;
                this.btnBuscarProduto.Enabled = true;

            }
            else
            {
                this.Habilitar(false);
                this.btnNovo.Enabled = true;
                this.btnSalvar.Enabled = false;
                this.btnBuscar.Enabled = true;
                this.btnCancelar.Enabled = false;
                this.btnBuscarCliente.Enabled = false;
                this.btnBuscarProduto.Enabled = false;
            }

        }

       

        //Ocultar as Colunas do Grid
        private void ocultarColunas()
        {
            this.dataLista1.Columns[0].Visible = false;
            
        }


        //Mostrar no Data Grid
        public void Mostrar()
        {
            this.dataLista1.DataSource = NVenda.Mostrar();
            this.ocultarColunas();
            lblTotal.Text = "Total de Registros: " + Convert.ToString(dataLista1.Rows.Count);
        }



        //Buscar por Datas
        private void BuscarData()
        {
            this.dataLista1.DataSource = NVenda.BuscarData(this.dtInicial.Value.ToString("yyyy/MM/dd"), this.dtFinal.Value.ToString("yyyy/MM/dd"));

            this.ocultarColunas();
            lblTotal.Text = "Total de Registros: " + Convert.ToString(dataLista1.Rows.Count);
        }


        //Mostrar Detalhe Entrada
        private void MostrarDetalheEntrada()
        {
            this.dataListaDetalhes.DataSource = NVenda.MostrarDetalhes(this.txtId.Text);

        }


        //BUSCAR O CLIENTE
        public void setCliente(string idcliente, string nome)
        {
            this.txtIdCliente.Text = idcliente;
            this.txtCliente.Text = nome;
        }

        //BUSCAR O PRODUTO
        public void setProduto(string iddetalhe_entrada, string nome,
            decimal preco_compra, decimal preco_venda, int estoque,
            DateTime data_vencimento)
        {
            this.txtIdProduto.Text = iddetalhe_entrada;
            this.txtProduto.Text = nome;
           this.txtPrecoCompra.Text = Convert.ToString(preco_compra);
            this.txtPrecoVenda.Text = Convert.ToString(preco_venda);
            this.txtEstoqueAtual.Text = Convert.ToString(estoque);
            this.dtVencimento.Value = data_vencimento;


        }


    private void frmVenda_Load(object sender, EventArgs e)
        {

            this.Mostrar();
            this.Habilitar(false);
            this.botoes();
            this.CriarTabela();
            this.cbComprovante.SelectedIndex = 0;
            this.cbTipoPagamento.SelectedIndex = 0;
            this.tabControl1.SelectedIndex = 1;
     
        }

        
        

        private void frmVenda_FormClosed(object sender, FormClosedEventArgs e)
        {
            _Instancia = null;
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            frmBuscarCliente frm = new frmBuscarCliente();
            frm.Show();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            this.eNovo = true;
            this.botoes();
            this.Limpar();
            this.Habilitar(true);
            this.txtSerie.Focus();
            this.LimparDetalhes();
            this.txtCliente.Text = "xxxxx";
            this.txtIdCliente.Text = "1";
            this.txtImposto.Text = "0";
            this.txtDesconto.Text = "0";
            this.txtquantidade.Text = "1";
        }

        private void btnBuscarProduto_Click(object sender, EventArgs e)
        {
            frmBuscarProdutoVenda frm = new frmBuscarProdutoVenda();
            frm.Show();
        }


        private void CriarTabela()
        {
            this.dtDetalhe = new DataTable("Detalhe");
            this.dtDetalhe.Columns.Add("iddetalhe_entrada", System.Type.GetType("System.Int32"));
            this.dtDetalhe.Columns.Add("produto", System.Type.GetType("System.String"));
            this.dtDetalhe.Columns.Add("quantidade", System.Type.GetType("System.Decimal"));
            this.dtDetalhe.Columns.Add("preco_venda", System.Type.GetType("System.Decimal"));
            this.dtDetalhe.Columns.Add("desconto", System.Type.GetType("System.Int32"));


            this.dtDetalhe.Columns.Add("subtotal", System.Type.GetType("System.Decimal"));
            // this.dtDetalhe.Columns.Add("imposto", System.Type.GetType("System.Decimal"));

            this.dataListaDetalhes.DataSource = this.dtDetalhe;

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.eNovo = false;

            this.botoes();
            this.Habilitar(false);
            this.Limpar();
            this.LimparDetalhes();
        }

        private void chkDeletar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDeletar.Checked)
            {
                this.dataLista1.Columns[0].Visible = true;
            }
            else
            {
                this.dataLista1.Columns[0].Visible = false;
            }
        }

        private void dataLista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataLista1.Columns["Deletar"].Index)
            {
                DataGridViewCheckBoxCell ChkDeletar = (DataGridViewCheckBoxCell)dataLista1.Rows[e.RowIndex].Cells["Deletar"];
                ChkDeletar.Value = !Convert.ToBoolean(ChkDeletar.Value);
            }
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult Opcao;
                Opcao = MessageBox.Show("Realmente Deseja deletar os Registros", "Sistema Comércio", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (Opcao == DialogResult.OK)
                {
                    string Codigo;
                    string Resp = "";

                    foreach (DataGridViewRow row in dataLista1.Rows)
                    {

                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {

                            Codigo = Convert.ToString(row.Cells[1].Value);
                            Resp = NVenda.Deletar(Convert.ToInt32(Codigo));

                            if (Resp.Equals("OK"))
                            {
                                this.MensagemOk("Registro deletado com sucesso");

                            }
                            else
                            {
                                this.MensagemErro(Resp);
                            }
                        }
                    }
                    this.Mostrar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        public void dataLista_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                this.txtId.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["idvenda"].Value);
                this.txtCliente.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["cliente"].Value);
                this.dtData.Value = Convert.ToDateTime(this.dataLista1.CurrentRow.Cells["data"].Value);
                this.cbComprovante.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["tipo_comprovante"].Value);
                this.txtSerie.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["serie"].Value);
                this.txtCorrelativo.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["correlativo"].Value);
                this.txtImposto.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["imposto"].Value);
                this.lblTotalPagar.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["total"].Value);
                this.cbTipoPagamento.Text = Convert.ToString(this.dataLista1.CurrentRow.Cells["tipo_pagamento"].Value);


                this.MostrarDetalheEntrada();
                this.tabControl1.SelectedIndex = 1;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
           
            try
            {
                
                

                
                string resp = "";
                if (this.txtIdCliente.Text == string.Empty ||
                    this.txtImposto.Text == string.Empty ||
                    this.txtSerie.Text == string.Empty)
                {
                    MensagemErro("Preencha todos os campos");
                    errorIcone.SetError(txtImposto, "Insira o Imposto");
                    errorIcone.SetError(txtIdCliente, "Insira o Fornecedor");
                    errorIcone.SetError(txtSerie, "Insira a série");


                }
                else
                {


                    if (this.eNovo)
                    {

                        resp = NVenda.Inserir(Convert.ToInt32(this.txtIdCliente.Text),
                            idfuncionario, dtData.Value, cbComprovante.Text,
                            txtSerie.Text, txtCorrelativo.Text,
                            Convert.ToDecimal(txtImposto.Text), dtDetalhe, this.cbTipoPagamento.Text);
                    }


                    if (resp.Equals("OK"))
                    {
                        if (this.eNovo)
                        {
                            frmReceberPagamento r = new frmReceberPagamento(Convert.ToString(this.totalPago));
                            r.ShowDialog();

                            this.MensagemOk("Registro salvo com sucesso");
                        }

                    }
                    else
                    {
                        this.MensagemErro(resp);
                    }

                    this.eNovo = false;

                    this.botoes();
                    this.Limpar();
                    this.Mostrar();
                    this.LimparDetalhes();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            finally
            {
                
                totalPago = valor;
                this.lblTotalPagar.Text = totalPago.ToString("R$ #0.00#");
            }
        }

        private decimal valor = 0;
        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string resp = "";
                if (this.txtIdProduto.Text == string.Empty || this.txtEstoqueAtual.Text == string.Empty || this.txtPrecoCompra.Text == string.Empty || this.txtDesconto.Text == string.Empty)
                {
                    MensagemErro("Preencha todos os campos");
                    errorIcone.SetError(txtIdProduto, "Insira o Produto");
                    errorIcone.SetError(txtEstoqueAtual, "Insira o Estoque Inicial");
                    errorIcone.SetError(txtPrecoCompra, "Insira o preço de compra");
                    errorIcone.SetError(txtPrecoCompra, "Insira o valor do desconto");

                }
                else
                {
                    bool salvar = true;
                    foreach (DataRow row in dtDetalhe.Rows)
                    {
                        if (Convert.ToInt32(row["iddetalhe_entrada"]) == Convert.ToInt32(this.txtIdProduto.Text))
                        {
                            salvar = false;
                            this.MensagemErro("O Produto já está nos detalhes");
                        }

                    }
                    if (salvar && Convert.ToInt32(txtquantidade.Text) <= Convert.ToInt32(txtEstoqueAtual.Text))
                    {
                        //codigo para adicionar ao data list
                        decimal subTotal = Convert.ToDecimal(this.txtquantidade.Text) * Convert.ToDecimal(this.txtPrecoVenda.Text) - Convert.ToDecimal(this.txtDesconto.Text);
                        totalPago = totalPago + subTotal;
                        this.lblTotalPagar.Text = totalPago.ToString("R$ #0.00#");

                        DataRow row = this.dtDetalhe.NewRow();
                        row["iddetalhe_entrada"] = Convert.ToInt32(this.txtIdProduto.Text);
                        row["produto"] = this.txtProduto.Text;
                        row["quantidade"] = Convert.ToInt32(this.txtquantidade.Text);
                        row["preco_venda"] = Convert.ToDecimal(this.txtPrecoVenda.Text);
                        row["desconto"] = this.txtDesconto.Text;

                        row["subtotal"] = subTotal;

                        this.dtDetalhe.Rows.Add(row);
                        this.LimparDetalhes();
                        this.btnBuscarProduto.Focus();
                    }
                    else
                    {
                        MensagemErro("Não há essa quantidade de produtos no estoque!");
                        this.txtquantidade.Text = string.Empty;
                        this.txtquantidade.Focus();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            finally
            {
               // this.lblTotalPagar.Text = totalPago.ToString("R$ #0.00#");
            }
        }



        private void btnRemover_Click(object sender, EventArgs e)
        {
            try
            {
                frmIdentificacao fr = new frmIdentificacao();
                fr.ShowDialog();
                DataTable Dados = CamadaNegocio.NFuncionario.Login(fr.txtUsuario.Text, fr.txtSenha.Text);
                if (Dados.Rows.Count == 0)
                {
                    MessageBox.Show("O Usuário não Existe, tente novamente!", "Sistema Comércio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    int indiceLinha = this.dataListaDetalhes.CurrentCell.RowIndex;
                    DataRow row = this.dtDetalhe.Rows[indiceLinha];

                    //abater o valor pago
                    this.totalPago = this.totalPago - Convert.ToDecimal(row["subtotal"].ToString());
                    this.lblTotalPagar.Text = totalPago.ToString("R$ #0.00#");

                    //remover a linha
                    this.dtDetalhe.Rows.Remove(row);
                }
            }
            catch (Exception ex)
            {
                MensagemErro("Não há linha para excluir!!");
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.BuscarData();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
           
            DateTime dat1 = DateTime.Parse(dtInicial.Text);
            DateTime dat2 = DateTime.Parse(dtFinal.Text);

            frmVendasDetalhadasPorCategoria dv = new frmVendasDetalhadasPorCategoria();
            dv.DadosVendas(dat1, dat2);
            dv.ShowDialog();
          
        }
        
        public void OcultarTab()
        {
            this.tabControl1.Controls.Remove(tabPage2);
            this.btnDeletar.Visible = false;
            this.chkDeletar.Visible = false;
            this.btnImprimir.Visible = false;
            this.dataLista1.Enabled = true;
        }

        private void FecharVEnda_Click(object sender, EventArgs e)
        {
            
          
            frmReceberPagamento rp = new frmReceberPagamento(Convert.ToString(this.totalPago));
            rp.ShowDialog();
            rp.txtValorRecebido.Focus();
        }

        
        public void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            
        }

        private void frmVenda_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.F1)
            {
                frmBuscarProdutoVenda frm = new frmBuscarProdutoVenda();
                frm.Show();
                
            }
            if (e.KeyCode == Keys.F2)
            {
                this.txtquantidade.Focus();
            }

            if (e.KeyCode == Keys.F3)
            {
                this.cbTipoPagamento.Text = "Dinheiro";
            }

            if (e.KeyCode == Keys.F4)
            {
                this.cbTipoPagamento.Text = "Cartão de Crédito";
            }

            if (e.KeyCode == Keys.F5)
            {
                this.cbTipoPagamento.Text = "Cartão de Débito";
            }

            if (e.KeyCode == Keys.F6)
            {
                this.btnRemover.PerformClick();
            }
            if(e.KeyCode == Keys.F7)
            {
                this.btnSalvar.PerformClick();
            }

            

        }
      
        private void txtFecharCaixa_Click(object sender, EventArgs e)
        {
            DateTime dat1 = DateTime.Parse(dtInicial.Text);
            DateTime dat2 = DateTime.Parse(dtFinal.Text);

            frmVendasPorDatas rl = new frmVendasPorDatas();
            rl.DadosVendas(dat1, dat2);
            rl.ShowDialog();
                  
            
            
        }

        private void btnDepositoCaixa_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmRelatorioFatura frm = new frmRelatorioFatura();
            frm.Idvenda = Convert.ToInt32(this.dataLista1.CurrentRow.Cells["idvenda"].Value);
            frm.ShowDialog();
        }

        
       
        
           
        
        private void bntMovimentarCaixa_Click(object sender, EventArgs e)
        {
            frmFecharCaixa f = frmFecharCaixa.GetInstancia();
            if (MessageBox.Show("Deseja realmente fechar o caixa", "ATENÇÂO", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                this.Close();
               
                f.MdiParent = CamadaApresentacao.frmPrincipal.ActiveForm;
                f.Show();
            }else
            {
                f.Hide();
            }
          
           
           
            
        }

        

        private void txtSerie_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btnBuscarProduto.Focus();
            }
        }

       

        private void txtquantidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtDesconto.Focus();
            }
        }

        private void btnAdd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnBuscarProduto.Focus();
            }
        }

     

        private void txtDesconto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd.Focus();
            }
        }

       
    }
    
}
