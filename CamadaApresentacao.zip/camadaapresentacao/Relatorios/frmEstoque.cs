﻿using System;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmEstoque : Form
    {
        public frmEstoque()
        {
            InitializeComponent();
        }

        private void frmEstoque_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'dsPrincipal.spestoque_produtos'. Você pode movê-la ou removê-la conforme necessário.
            try
            {
                this.spestoque_produtosTableAdapter.Fill(this.dsPrincipal.spestoque_produtos);

                this.reportViewer1.RefreshReport();
            }catch(Exception ex)
            {
                this.reportViewer1.RefreshReport();
            }
        }
    }
}
