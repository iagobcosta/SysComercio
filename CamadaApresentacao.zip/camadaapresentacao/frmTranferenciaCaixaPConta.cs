﻿using CamadaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmTranferenciaCaixaPConta : Form
    {
        private string Nome;
        private string Sobrenome;
        public frmTranferenciaCaixaPConta(string nome, string sobrenome)
        {
            InitializeComponent();
            this.Nome = nome.ToString();
            this.Sobrenome = sobrenome.ToString();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            try
            {
                if(cbtiposDeTansf.Text == " Caixa / CC")
                {
                    NContaLoja.transferirCaixaPConta(Convert.ToInt32(txtCodigo.Text), Convert.ToDecimal(txtValor.Text));
                    MessageBox.Show("Transferência realizada com sucesso para sua conta corrente!","Atenção",MessageBoxButtons.OK);

                    DataTable dados1 = CamadaNegocio.NEmpresa.Mostrar();
                    using (var doc = new PdfSharp.Pdf.PdfDocument())
                    {
                        var page = doc.AddPage();
                        var graphics = PdfSharp.Drawing.XGraphics.FromPdfPage(page);
                        var textFormatter = new PdfSharp.Drawing.Layout.XTextFormatter(graphics);
                        var font = new PdfSharp.Drawing.XFont("Arial", 12);
                        textFormatter.Alignment = PdfSharp.Drawing.Layout.XParagraphAlignment.Center;
                        //escrevendo no arquivo
                        try
                        {
                            textFormatter.DrawString("         *TRANSFERÊNCIA PARA CONTA CORRENTE*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 30, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString(dados1.Rows[0][1].ToString() + " -- " + DateTime.Now.ToString(), font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 50, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Nome do Funcionário: " + this.Nome + "-" + this.Sobrenome, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 70, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Número da conta: " + txtCodigo.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 90, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Valor do Transferência: R$" + txtValor.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 110, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Observação: " + txtObservacao.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 130, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("         *TRANSFERÊNCIA PARA CONTA CORRENTE*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 150, page.Width - 60, page.Height - 60));


                            doc.Save("arquivo.pdf");
                            System.Diagnostics.Process.Start("arquivo.pdf");
                            MessageBox.Show("Arquivo Gerado com sucesso !", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erro ao Gerar arquivo !!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                else if(cbtiposDeTansf.Text == "Caixa / Lucro")
                {
                    NContaLoja.transferirCaixaPLucro(Convert.ToInt32(txtCodigo.Text), Convert.ToDecimal(txtValor.Text));
                    MessageBox.Show("Transferência realizada com sucesso para seu lucro!", "Atenção", MessageBoxButtons.OK);

                    DataTable dados1 = CamadaNegocio.NEmpresa.Mostrar();
                    using (var doc = new PdfSharp.Pdf.PdfDocument())
                    {
                        var page = doc.AddPage();
                        var graphics = PdfSharp.Drawing.XGraphics.FromPdfPage(page);
                        var textFormatter = new PdfSharp.Drawing.Layout.XTextFormatter(graphics);
                        var font = new PdfSharp.Drawing.XFont("Arial", 12);
                        textFormatter.Alignment = PdfSharp.Drawing.Layout.XParagraphAlignment.Center;
                        //escrevendo no arquivo
                        try
                        {
                            textFormatter.DrawString("         *TRANSFERÊNCIA PARA O LUCRO*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 30, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString(dados1.Rows[0][1].ToString() + " -- " + DateTime.Now.ToString(), font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 50, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Nome do Funcionário: " + this.Nome + "-" + this.Sobrenome, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 70, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Número da conta: " + txtCodigo.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 90, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Valor do Transferência: R$" + txtValor.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 110, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("Observação: " + txtObservacao.Text, font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 130, page.Width - 60, page.Height - 60));
                            textFormatter.DrawString("         *TRANSFERÊNCIA PARA O LUCRO*", font, PdfSharp.Drawing.XBrushes.Black, new PdfSharp.Drawing.XRect(30, 150, page.Width - 60, page.Height - 60));


                            doc.Save("arquivo.pdf");
                            System.Diagnostics.Process.Start("arquivo.pdf");
                            MessageBox.Show("Arquivo Gerado com sucesso !", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erro ao Gerar arquivo !!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message + "ERRO");
            }

            

        }
    }
}
