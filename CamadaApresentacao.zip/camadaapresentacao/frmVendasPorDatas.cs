﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmVendasPorDatas : Form
    {
        public frmVendasPorDatas()
        {
            InitializeComponent();
        }

        private void frmVendasPorDatas_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'dsPrincipal.spmostrar_venda'. Você pode movê-la ou removê-la conforme necessário.
            //this.spmostrar_vendaTableAdapter.Fill(this.dsPrincipal.spmostrar_venda);

            //this.reportViewer1.RefreshReport();
        }
        public void DadosVendas (DateTime x, DateTime y)
        {
            try
            {
                this.spmostrar_vendaTableAdapter.Fill(this.dsPrincipal.spmostrar_venda, x, y);
                this.reportViewer1.RefreshReport();
            }
            catch(Exception ex)
            {
                MessageBox.Show("erro aqui");
            }
        }
    }
}
