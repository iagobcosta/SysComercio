﻿using CamadaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmPrincipal : Form
    {
        private int childFormNumber = 0;
        public string IdFuncionario = "";
        public string Nome = "";
        public string Sobrenome = "";
        public string Acesso = "";
       




        public frmPrincipal()
        {
            InitializeComponent();
            frmLogin lb = new frmLogin();
            

        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Janela " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Arquivos de texto (*.txt)|*.txt|Todos os arquivos (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Arquivos de texto (*.txt)|*.txt|Todos os arquivos (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip.Visible = toolBarToolStripMenuItem.Checked;
        }

       

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoria frm = frmCategoria.GetInstancia();
            frm.MdiParent = this;
            frm.Show();

        }

        private void apresentaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            frmApresentacao frm = frmApresentacao.GetInstancia();
            frm.MdiParent = this;
            frm.Show();

        }

        private void produtosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmProduto frm = frmProduto.GetInstancia();
            frm.MdiParent = this;
            frm.Show();

        }
        
        private void frmPrincipal_Load(object sender, EventArgs e)
        {

            frmMovimentarCaixa f = new frmMovimentarCaixa();
            f.IdFuncionario = IdFuncionario;
            
                GestaoUsuario();
                lbNome.Text = Nome.ToLower();
                lbacesso.Text = Acesso;
                data1.Text = DateTime.Now.ToShortDateString();
            

            /*frmVenda frm = frmVenda.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
            frm.idfuncionario = Convert.ToInt32(this.IdFuncionario);*/
        }


        private void GestaoUsuario()
        {
            if (Acesso == "Administrador")
            {
                MenuProdutos.Enabled = true;
                MenuVendas.Enabled = true;
                MenuCompras.Enabled = true;
                MenuConsultas.Enabled = true;
                MenuFerramentas.Enabled = true;
                MenuConfiguracoes.Enabled = true;
                MenuExibir.Enabled = true;
                MenuJanela.Enabled = true;
                MenuSistema.Enabled = true;
            }
            else if (Acesso == "Gerente")
            {
                MenuProdutos.Enabled = true;
                MenuVendas.Enabled = true;
                MenuCompras.Enabled = true;
                MenuConsultas.Enabled = true;
                MenuFerramentas.Enabled = false;
                MenuConfiguracoes.Enabled = true;
                MenuExibir.Enabled = true;
                MenuJanela.Enabled = true;
                MenuSistema.Enabled = true;
            }
            else 
            {
                MenuProdutos.Enabled = true;
                MenuVendas.Enabled = true;
                MenuCompras.Enabled = false;
                MenuConsultas.Enabled = true;
                MenuFerramentas.Enabled = false;
                MenuConfiguracoes.Enabled = false;
                MenuExibir.Enabled = true;
                MenuJanela.Enabled = true;
                MenuSistema.Enabled = true;
            }
        }

        private void fornecedoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFornecedor frm = frmFornecedor.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
        }

        private void entradaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntrada frm = frmEntrada.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
            frm.idfuncionario = Convert.ToInt32(this.IdFuncionario);
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCliente frm =  frmCliente.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
        }

        private void vendasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SqlConnection con1 = new SqlConnection(CamadaNegocio.NConexao.conexao1());
            con1.Close();
            con1.Open();
            SqlCommand sqlCon = new SqlCommand("SELECT * FROM movimentacaoCaixa WHERE ativo='1'  AND data_Abertura  < GETDATE()", con1);
            SqlDataReader sqlRade = sqlCon.ExecuteReader();

            if (caixaAberto == true)
            {
                frmVenda frm = frmVenda.GetInstancia();
                frm.MdiParent = this;
                frm.Show();
                frm.idfuncionario = Convert.ToInt32(IdFuncionario);
            }
            
             else if(sqlRade.HasRows)
            {
                MessageBox.Show("Impossivel abrir novo caixa! Ainda a um caixa aberto vá em CONSULTAS-> MOVIMENTAÇÕES DE CAIXA. E execute o procedimento para finalizar o caixa aberto!", "ATENÇÂO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                frmMovimentarCaixa f = frmMovimentarCaixa.GetInstancia();
                f.MdiParent = this;
                f.Show();
            }
           
            con1.Close();
        }

        public static bool caixaAberto = false;
       

        public static void AbrirCaixa(string usu, string senha, string valor)
        {
            try
            {
                SqlConnection con = new SqlConnection(NConexao.conexao1());
                con.Close();
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM funcionario where senha = '" + senha + "' AND usuario = '" + usu + "'", con);
                SqlDataReader leitor = cmd.ExecuteReader();
                if (leitor.HasRows)
                {
                    string id;
                    leitor.Read();
                    id = leitor["idfuncionario"].ToString();
                    leitor.Close();
                    con.Close();
                    con.Open();
                    //NMovimentarCaixa.Inserir(Convert.ToInt32(id), valor, Convert.ToBoolean(1), Convert.ToDateTime( DateTime.Now.ToString()),);
                    SqlCommand cmd1 = new SqlCommand("INSERT INTO movimentacaoCaixa (id_funcionario,valor_inicial,ativo,data_Abertura,saida) VALUES ('" + id + "','" + valor + "','1','" + DateTime.Now.ToString("yyyy/MM/dd") + "','0')", con);
                    cmd1.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("movimentação realizada com sucesso!", "ATENÇÂO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    caixaAberto = true;
                   


                }
                else
                {
                    MessageBox.Show("Usuario ou senha incorretos, impossivél abrir movimentação!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar abrir movimentação!");
            }
        }
        string _id;
        public string idFuncionario()
        {
            _id = IdFuncionario;
            return _id;
        }


        private void estoqueDeProdutosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Consultas.frmConsulta_Estoque_Produtos frm = new Consultas.frmConsulta_Estoque_Produtos();
            frm.Show();
        }

        private void vendasPorDatasToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            
        }

       

        private void backupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.dropbox.com/s/pmp1ljpqgugclvq/dbcomercio.rar?dl=0");
        }

        private void funcionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFuncionario frm = frmFuncionario.GetInstancia();
            frm.MdiParent = this;
            
            frm.Show();
        }

        

        private void trocarUsuárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

           



        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            frmVenda frm = frmVenda.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
            frm.idfuncionario = Convert.ToInt32(this.IdFuncionario);
        }

        private void TSCompras_Click(object sender, EventArgs e)
        {

            frmEntrada frm = frmEntrada.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
            frm.idfuncionario = Convert.ToInt32(this.IdFuncionario);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)                   
        {
            hora1.Text = DateTime.Now.ToLongTimeString();
        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

            frmFuncionario frm = frmFuncionario.GetInstancia();
            frm.MdiParent = this;

            frm.Show();
        }

        private void empresaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEmpresa frm = FrmEmpresa.GetInstancia();
            frm.MdiParent = this;
            frm.Show();
            
        }

        private void lbHoras_Click(object sender, EventArgs e)
        {

        }

        private void depositarDinheiroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContaLoja con = new frmContaLoja();
            con.ShowDialog();
        }

        private void caixaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmDepositarCaixa dc = new frmDepositarCaixa(this.Nome,this.Sobrenome);
            dc.ShowDialog();
        }

        private void caixaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            frmSaqueDoCaixa frm = new frmSaqueDoCaixa(this.Nome,this.Sobrenome);
            frm.ShowDialog();
        }

        private void contaCorrenteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmDepositoCC dc = new frmDepositoCC(this.Nome,this.Sobrenome);
            dc.ShowDialog();
        }

        private void lucroToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmDepositoLucro dl = new frmDepositoLucro(this.Nome, this.Sobrenome);
            dl.ShowDialog();
        }

        private void contaCorrenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSaqueDaContaC sc = new frmSaqueDaContaC(this.Nome, this.Sobrenome);
            sc.ShowDialog();
        }

        private void lucroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSaqueDoLucro sl = new frmSaqueDoLucro(this.Nome,this.Sobrenome);
            sl.ShowDialog();
        }

        private void financeiroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void transferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTranferenciaCaixaPConta t = new frmTranferenciaCaixaPConta(this.Nome, this.Sobrenome);
            t.ShowDialog();
        }

       

        private void movimentaçõesDeCaixasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMovimentcoesDeCaixa m = new frmMovimentcoesDeCaixa();
            m.MdiParent = this;
            m.Show();
        }

        private void abrirCaixaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIdentificacao i = new frmIdentificacao();
            i.MdiParent = this;
            i.Show();
            frmPrincipal.caixaAberto = true;
            
        }
    }
    }

