﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmDetalhesVendas : Form
    {
        public frmDetalhesVendas()
        {
            InitializeComponent();
        }

        private void frmDetalhesVendas_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsPrincipal.sp_detalhes_venda' table. You can move, or remove it, as needed.
            //this.sp_detalhes_vendaTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda);
            // TODO: esta linha de código carrega dados na tabela 'dsPrincipal.sp_detalhes_venda1'. Você pode movê-la ou removê-la conforme necessário.
            //this.sp_detalhes_venda1TableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda1);

            //this.reportViewer1.RefreshReport();
            //this.reportViewer1.RefreshReport();
        }
        public void detalheVendas(DateTime x, DateTime y)
        {
            try
            {
                this.sp_detalhes_vendaTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda, x, y);
               

                this.reportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {
                this.reportViewer1.RefreshReport();
                MessageBox.Show(ex.Message);
            }

        }
    }
}
