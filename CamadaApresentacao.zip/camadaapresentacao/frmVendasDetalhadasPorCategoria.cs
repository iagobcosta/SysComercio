﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CamadaApresentacao
{
    public partial class frmVendasDetalhadasPorCategoria : Form
    {
        public frmVendasDetalhadasPorCategoria()
        {
            InitializeComponent();
        }

        private void frmVendasDetalhadasPorCategoria_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsPrincipal.sp_detalhes_venda_em_catao_de_debito' table. You can move, or remove it, as needed.
            // this.sp_detalhes_venda_em_catao_de_debitoTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda_em_catao_de_debito);
            // TODO: This line of code loads data into the 'dsPrincipal.sp_detalhes_venda_em_catao_de_credito' table. You can move, or remove it, as needed.
            //this.sp_detalhes_venda_em_catao_de_creditoTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda_em_catao_de_credito);
            // TODO: This line of code loads data into the 'dsPrincipal.sp_detalhes_venda' table. You can move, or remove it, as needed.
            //this.sp_detalhes_vendaTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda);

            //this.reportViewer1.RefreshReport();
        }
        public void DadosVendas(DateTime x, DateTime y)
        {

            try
            {
                this.sp_detalhes_venda_em_catao_de_debitoTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda_em_catao_de_debito, x, y);
                this.sp_detalhes_venda_em_catao_de_creditoTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda_em_catao_de_credito, x, y);
                this.sp_detalhes_vendaTableAdapter.Fill(this.dsPrincipal.sp_detalhes_venda, x, y);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro aqui");
            }
        }
        
    }
}

