﻿using CamadaDados;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaNegocio
{
   public class NContaLoja
    {

        //Método Inserir
        public static string Inserir(int idLoja,int idfuncionario,   decimal saldoCaixa, decimal contaCorrente, decimal lucro)
        {
            DContaLoja Obj = new CamadaDados.DContaLoja();
            Obj.Id_funcionario = idfuncionario;
            Obj.Id_loja = idLoja;
           
            Obj.Saldo_caixa = saldoCaixa;
            Obj.Conta_corrente = contaCorrente;
            Obj.Lucro = lucro;

            return Obj.Inserir(Obj);
        }

        //Métado depositar caixa
        public static string inserirCaixa(int idloja,decimal saldodoCaixa)
        {
            DContaLoja d = new DContaLoja();
             return d.depositarDinheiroDoCaixa(idloja,saldodoCaixa);
        }

        //Métado depositar conta corrente
        public static string inserirContaCorrente(int idloja, decimal contaCorrente)
        {
            DContaLoja d = new DContaLoja();
            return d.depositarDinheiroDaContaCorrente(idloja, contaCorrente);
        }

        //Métado depositar conta corrente
        public static string inserirLucro(int idloja, decimal lucro)
        {
            DContaLoja d = new DContaLoja();
            return d.depositarDinheiroDoLucro(idloja, lucro);
        }

        //Método Saque do caixa
        public static string saqueDoCaixa(int codigo, decimal saldoDoCaixa)
        {
            DContaLoja d = new DContaLoja();
            return d.SacarDinheiroDoCaixa(codigo, saldoDoCaixa);
        }


        //Método Saque do C/C
        public static string saqueDContaCorrente(int codigo, decimal saldoDoCaixa)
        {
            DContaLoja d = new DContaLoja();
            return d.SacarDinheiroDaContaCorrente(codigo, saldoDoCaixa);
        }

        //Métado de transferencia do caixa para conta corrente
        public static string transferirCaixaPConta(int codigo, decimal valor)
        {
            DContaLoja d = new DContaLoja();
            return d.transferirCaixaPConta(codigo, valor);
        }

        //Métado de transferencia do caixa para lucro
        public static string transferirCaixaPLucro(int codigo, decimal valor)
        {
            DContaLoja d = new DContaLoja();
            return d.transferirCaixaPLucro(codigo, valor);
        }

        //Método Saque do Lucro
        public static string saqueDoLucro(int codigo, decimal saldoDoCaixa)
        {
            DContaLoja d = new DContaLoja();
            return d.SacarDinheiroDoLucro(codigo, saldoDoCaixa);
        }



        //Método Mostrar
        public static DataTable Mostrar()
        {
            return new DContaLoja().Mostrar();

        }        

        //Método Buscar por Data
        public static DataTable BuscarData(DateTime dat1, DateTime dat2)
        {
            DContaLoja Obj = new DContaLoja();
            return Obj.BuscarData(dat1, dat2);
        }
    }
}
