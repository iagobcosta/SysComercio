﻿using CamadaDados;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaNegocio
{
   public class NMovimentacaoDeCaixa
    {
        //Método Buscar caixa Aberto
        public static DataTable BuscarCaixaAbero(string data1,string data2)
        {
            DMovimentacaoDeCaixa Obj = new DMovimentacaoDeCaixa();
           
            return Obj.buscarCaixaAberto(data1,data2);
        }

        //Método Buscar caixa fechado
        public static DataTable BuscarCaixafechado(string data1, string data2)
        {
            DMovimentacaoDeCaixa Obj = new DMovimentacaoDeCaixa();
           
            return Obj.buscarCaixaFechado(data1,data2);
        }

        public static DataTable mostrarCaixas()
        {

            return new DMovimentacaoDeCaixa().Mostrar();
        }
    }

    
}
