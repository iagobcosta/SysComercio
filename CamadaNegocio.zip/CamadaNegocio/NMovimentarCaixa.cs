﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CamadaDados;
using System.Data;

namespace CamadaNegocio
{
   public class NMovimentarCaixa
    {
        public static string Inserir(int id_funcionario, decimal valorInicial, bool ativo, DateTime dataAbertura)
        {
            DMovimentarCaixa Obj = new DMovimentarCaixa();
            Obj.IdFuncionario = id_funcionario;
            Obj.ValorInicial = valorInicial;
            Obj.Ativo = ativo;
            Obj.DataAbertura = dataAbertura;

            return Obj.inserir(Obj);
        }

        public static string verificarAbertura()
        {
            return CamadaDados.Conexao.Cn;
        }
        
    }
}
