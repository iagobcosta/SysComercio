﻿using CamadaDados;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaNegocio
{
    public class NConexao
    {
       
        public static string conexao1()
        {
            return new Conexao().con;
           
        }
    }
}
