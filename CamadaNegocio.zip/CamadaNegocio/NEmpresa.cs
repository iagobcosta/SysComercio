﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CamadaDados;

namespace CamadaNegocio
{
   public class NEmpresa
    {
        //Método Inserir
        public static string Inserir(string razao_social, string endereco, string bairro,
            string cidade, string ie, string cnpj, string telefone,string nome_fantasia,
            string numero, string ccf, string coo, string estado)
        {
            DEmpresa Obj = new CamadaDados.DEmpresa();
            Obj.Razao_social = razao_social;
            Obj.Endereco = endereco;
            Obj.Bairro = bairro;
            Obj.Cidade = cidade;
            Obj.IE = ie;
            Obj.Cnpj = cnpj;
            Obj.Telefone = telefone;
            Obj.Nome_fantasia = nome_fantasia;
            Obj.Numero = numero;
            Obj.Ccf = ccf;
            Obj.Coo = coo;
            Obj.Estado = estado;
            
            return Obj.Inserir(Obj);
        }

        //Método Editar
        public static string Editar(int id, string razao_social, string endereco, string bairro,
            string cidade, string ie, string cnpj, string telefone, string nome_fantasia,
            string numero, string ccf, string coo, string estado)
        {
            DEmpresa Obj = new CamadaDados.DEmpresa();
            Obj.Id = id;
            Obj.Razao_social = razao_social;
            Obj.Endereco = endereco;
            Obj.Bairro = bairro;
            Obj.Cidade = cidade;
            Obj.IE = ie;
            Obj.Cnpj = cnpj;
            Obj.Telefone = telefone;
            Obj.Nome_fantasia = nome_fantasia;
            Obj.Numero = numero;
            Obj.Ccf = ccf;
            Obj.Coo = coo;
            Obj.Estado = estado;
            return Obj.Editar(Obj);
        }
        //metado excluir
        public static string Excluir(int id)
        {
            DEmpresa Obj = new CamadaDados.DEmpresa();
            Obj.Id = id;

            return Obj.Excluir(Obj);
        }

        //Método Mostrar
        public static DataTable Mostrar()
        {
            return new DEmpresa().Mostrar();


        }

        //Método Buscar Nome
        public static DataTable BuscarNome(string textobuscar)
        {
            DEmpresa Obj = new DEmpresa();
            Obj.TextoBuscar = textobuscar;
            return Obj.BuscarNome(Obj);
        }

        //Método Buscar Cnpj
        public static DataTable BuscarCnpj(string textobuscar)
        {
            DEmpresa Obj = new DEmpresa();
            Obj.TextoBuscar = textobuscar;
            return Obj.BuscarCnpj(Obj);
        }

    }
}
