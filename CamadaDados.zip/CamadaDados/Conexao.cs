﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaDados
{
   public class Conexao
    {
        public string con = Cn;
        public static string Cn = "Data Source=DESKTOP-QJK81V0\\SQLEXPRESS;Initial Catalog=bancoComercio;User ID=sa;Password=1994";

       
       
        
        
    }

}    
   


      
    
  

