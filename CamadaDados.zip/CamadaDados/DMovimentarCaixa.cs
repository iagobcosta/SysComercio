﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CamadaDados
{
  public  class DMovimentarCaixa
    {
        private int _id;
        private int _idFuncionario;
        private decimal _valorInicial;
        private bool _ativo;
        private DateTime _dataAbertura;

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public int IdFuncionario
        {
            get
            {
                return _idFuncionario;
            }

            set
            {
                _idFuncionario = value;
            }
        }

        public decimal ValorInicial
        {
            get
            {
                return _valorInicial;
            }

            set
            {
                _valorInicial = value;
            }
        }

        public bool Ativo
        {
            get
            {
                return _ativo;
            }

            set
            {
                _ativo = value;
            }
        }

        public DateTime DataAbertura
        {
            get
            {
                return _dataAbertura;
            }

            set
            {
                _dataAbertura = value;
            }
        }

        public DMovimentarCaixa()
        {

        }

        public DMovimentarCaixa(int id,int idFuncionario,decimal valorInicial,bool ativo,DateTime dataAbertura)
        {
            this.Id = id;
            this.IdFuncionario = IdFuncionario;
            this.ValorInicial = valorInicial;
            this.Ativo = ativo;
            this.DataAbertura = dataAbertura;

        }

        public  string inserir(DMovimentarCaixa movimentoCaixa)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "inserirMovimento";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParId = new SqlParameter();
                ParId.ParameterName = "@id";
                ParId.SqlDbType = SqlDbType.Int;
                ParId.Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add(ParId);

                SqlParameter ParidFuncionario = new SqlParameter();
                ParidFuncionario.ParameterName = "@id_funcionario";
                ParidFuncionario.SqlDbType = SqlDbType.Int;                
                ParidFuncionario.Value = movimentoCaixa.IdFuncionario;
                SqlCmd.Parameters.Add(ParidFuncionario);

                SqlParameter ParValorInicial = new SqlParameter();
                ParValorInicial.ParameterName = "@valor_inicial";
                ParValorInicial.SqlDbType = SqlDbType.Decimal;
                ParValorInicial.Value = movimentoCaixa.ValorInicial;
                SqlCmd.Parameters.Add(ParValorInicial);

                SqlParameter ParAtivo = new SqlParameter();
                ParAtivo.ParameterName = "@ativo";
                ParAtivo.SqlDbType = SqlDbType.Bit;
                ParAtivo.Value = movimentoCaixa.Ativo;
                SqlCmd.Parameters.Add(ParAtivo);

                SqlParameter ParDataAbertura = new SqlParameter();
                ParDataAbertura.ParameterName = "@data_abertura";
                ParDataAbertura.SqlDbType = SqlDbType.Bit;
                ParDataAbertura.Value = movimentoCaixa.DataAbertura;
                SqlCmd.Parameters.Add(ParDataAbertura);

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "Registro não foi Inserido";

            }
            catch(Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;
        }

    }
}
