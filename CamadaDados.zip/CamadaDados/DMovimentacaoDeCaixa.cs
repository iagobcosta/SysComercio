﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CamadaDados
{
    public class DMovimentacaoDeCaixa
    {
        private string _data1;
        private string _data2;

        public string Data1
        {
            get
            {
                return _data1;
            }

            set
            {
                _data1 = value;
            }
        }

        public string Data2
        {
            get
            {
                return _data2;
            }

            set
            {
                _data2 = value;
            }
        }

        public DMovimentacaoDeCaixa()
        {

        }

        public DMovimentacaoDeCaixa(string data1, string data2)
        {
            this.Data1 = data1;
            this.Data2 = data2;
        }

        //Método Buscar por data aberto
        public DataTable buscarCaixaAberto(string data1, string data2)
        {
            DataTable DtResultado = new DataTable("movimentacaoCaixa");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "buscarCaixaAberto";
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlParameter Pardata1 = new SqlParameter();
                Pardata1.ParameterName = "@data1";
                Pardata1.SqlDbType = SqlDbType.VarChar;
                Pardata1.Size = 20;           
                Pardata1.Value = data1;
                SqlCmd.Parameters.Add(Pardata1);

                SqlParameter Pardata2 = new SqlParameter();
                Pardata2.ParameterName = "@data2";
                Pardata2.SqlDbType = SqlDbType.VarChar;
                Pardata2.Size = 20;             
                Pardata2.Value = data2;
                SqlCmd.Parameters.Add(Pardata2);

               SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }

        //Método Buscar por data fechado
        public DataTable buscarCaixaFechado( string data1,string data2)
        {
            DataTable DtResultado = new DataTable("movimentacaoCaixa");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "buscarCaixaFechado";
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlParameter Pardata1 = new SqlParameter();
                Pardata1.ParameterName = "@data1";
                Pardata1.SqlDbType = SqlDbType.VarChar;
                Pardata1.Size = 20;              
                Pardata1.Value =data1;
                SqlCmd.Parameters.Add(Pardata1);

                SqlParameter Pardata2 = new SqlParameter();
                Pardata2.ParameterName = "@data2";
                Pardata2.SqlDbType = SqlDbType.VarChar;
                Pardata2.Size = 20;              
                Pardata2.Value = data2;
                SqlCmd.Parameters.Add(Pardata2);

                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }


        //Método Mostrar
        public DataTable Mostrar()
        {
            DataTable DtResultado = new DataTable("movimentacaoCaixa");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "mostrarCaixas";
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }
    }

}
