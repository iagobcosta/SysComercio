﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaDados
{
    public class DContaLoja
    {
        private int _id_loja;
        private int _id_funcionario;
        private int _i_venda;        
        private decimal _saldo_caixa;
        private decimal _conta_corrente;
        private decimal lucro;

        public int Id_loja
        {
            get
            {
                return _id_loja;
            }

            set
            {
                _id_loja = value;
            }
        }

        public int Id_funcionario
        {
            get
            {
                return _id_funcionario;
            }

            set
            {
                _id_funcionario = value;
            }
        }

        public int I_venda
        {
            get
            {
                return _i_venda;
            }

            set
            {
                _i_venda = value;
            }
        }
        
        public decimal Saldo_caixa
        {
            get
            {
                return _saldo_caixa;
            }

            set
            {
                _saldo_caixa = value;
            }
        }

        public decimal Conta_corrente
        {
            get
            {
                return _conta_corrente;
            }

            set
            {
                _conta_corrente = value;
            }
        }

        public decimal Lucro
        {
            get
            {
                return lucro;
            }

            set
            {
                lucro = value;
            }
        }

        public DContaLoja()
        {

        }

        public DContaLoja(int id_loja, int id_funcionario,
            decimal saldo_caixa, decimal conta_corrente, decimal lucro)
        {
            this.Id_loja = id_loja;
            this.Id_funcionario = id_funcionario;           
            
            this.Saldo_caixa = saldo_caixa;
            this.Conta_corrente = conta_corrente;
            this.Lucro = lucro;
        }

        

        public string depositarDinheiroDoCaixa(int codigo, decimal saldoCaixa)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spDepositoNoCaixa";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdLoja = new SqlParameter();
                ParIdLoja.ParameterName = "@id_loja";
                ParIdLoja.SqlDbType = SqlDbType.Int;
                ParIdLoja.Value = codigo;
                SqlCmd.Parameters.Add(ParIdLoja);

                SqlParameter ParSaldoCaixa = new SqlParameter();
                ParSaldoCaixa.ParameterName = "@saldo_caixa";
                ParSaldoCaixa.SqlDbType = SqlDbType.Decimal;
                ParSaldoCaixa.Value = saldoCaixa;
                SqlCmd.Parameters.Add(ParSaldoCaixa);

                

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string SacarDinheiroDoCaixa(int codigo, decimal saldo_caixa)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spSaqueDoCaixa";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = codigo;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter ParSaldoCaixa = new SqlParameter();
                ParSaldoCaixa.ParameterName = "@saldo_caixa";
                ParSaldoCaixa.SqlDbType = SqlDbType.Decimal;
                ParSaldoCaixa.Value = saldo_caixa;
                SqlCmd.Parameters.Add(ParSaldoCaixa);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string depositarDinheiroDaContaCorrente(int id_loja, decimal conta_corrente)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spDepositoNaContaCorrente";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = id_loja;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter Parconta_corrente = new SqlParameter();
                Parconta_corrente.ParameterName = "@conta_corrente";
                Parconta_corrente.SqlDbType = SqlDbType.Decimal;
                Parconta_corrente.Value = conta_corrente;
                SqlCmd.Parameters.Add(Parconta_corrente);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string SacarDinheiroDaContaCorrente(int id_loja, decimal conta_corrente)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spSaqueDaContaCorrente";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = id_loja;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter Parconta_corrente = new SqlParameter();
                Parconta_corrente.ParameterName = "@conta_corrente";
                Parconta_corrente.SqlDbType = SqlDbType.Decimal;
                Parconta_corrente.Value = conta_corrente;
                SqlCmd.Parameters.Add(Parconta_corrente);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string depositarDinheiroDoLucro(int id_loja, decimal lucro)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spDepositoNoLucro";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = id_loja;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter Parconta_corrente = new SqlParameter();
                Parconta_corrente.ParameterName = "@lucro";
                Parconta_corrente.SqlDbType = SqlDbType.Decimal;
                Parconta_corrente.Value = lucro;
                SqlCmd.Parameters.Add(Parconta_corrente);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string SacarDinheiroDoLucro(int id_loja, decimal lucro)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spSaqueDoLucro";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = id_loja;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter Parconta_corrente = new SqlParameter();
                Parconta_corrente.ParameterName = "@lucro";
                Parconta_corrente.SqlDbType = SqlDbType.Decimal;
                Parconta_corrente.Value = lucro;
                SqlCmd.Parameters.Add(Parconta_corrente);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string transferirCaixaPConta(int id_loja, decimal valor)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "transferirCaixaPConta";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = id_loja;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter ParValor = new SqlParameter();
                ParValor.ParameterName = "@valor";
                ParValor.SqlDbType = SqlDbType.Decimal;
                ParValor.Value = valor;
                SqlCmd.Parameters.Add(ParValor);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        public string transferirCaixaPLucro(int id_loja, decimal valor)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "transferirCaixaPLucro";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdloja = new SqlParameter();
                ParIdloja.ParameterName = "@id_loja";
                ParIdloja.SqlDbType = SqlDbType.Int;
                ParIdloja.Value = id_loja;
                SqlCmd.Parameters.Add(ParIdloja);

                SqlParameter ParValor = new SqlParameter();
                ParValor.ParameterName = "@valor";
                ParValor.SqlDbType = SqlDbType.Decimal;
                ParValor.Value = valor;
                SqlCmd.Parameters.Add(ParValor);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;


        }

        //Método Mostrar
        public DataTable Mostrar()
        {
            DataTable DtResultado = new DataTable("contaLoja");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spMostrarContaLoja";
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }

        //Método Inserir
        public string Inserir(DContaLoja depisito)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //Código
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();


                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;     
                SqlCmd.CommandText = "spEditarContaLoja";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParIdLoja = new SqlParameter();
                ParIdLoja.ParameterName = "@id_loja";
                ParIdLoja.SqlDbType = SqlDbType.Int;
                ParIdLoja.Value = depisito.Id_loja;
                SqlCmd.Parameters.Add(ParIdLoja);

                SqlParameter ParIdFuncionario = new SqlParameter();
                ParIdFuncionario.ParameterName = "@id_funcionario";
                ParIdFuncionario.SqlDbType = SqlDbType.Int;
                ParIdFuncionario.Value = depisito.Id_funcionario;
                SqlCmd.Parameters.Add(ParIdFuncionario); 

               

                SqlParameter ParSaldoCaixa = new SqlParameter();
                ParSaldoCaixa.ParameterName = "@saldo_caixa";
                ParSaldoCaixa.SqlDbType = SqlDbType.Decimal;
                ParSaldoCaixa.Value = depisito.Saldo_caixa;
                SqlCmd.Parameters.Add(ParSaldoCaixa);

                SqlParameter ParContaCorrente = new SqlParameter();
                ParContaCorrente.ParameterName = "@conta_corrente";
                ParContaCorrente.SqlDbType = SqlDbType.Decimal;
                ParContaCorrente.Value = depisito.Conta_corrente;
                SqlCmd.Parameters.Add(ParContaCorrente);

                SqlParameter ParLucro = new SqlParameter();
                ParLucro.ParameterName = "@lucro";
                ParLucro.SqlDbType = SqlDbType.Decimal;
                ParLucro.Value = depisito.Lucro;
                SqlCmd.Parameters.Add(ParLucro);

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A atualização não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;

        }

        //Método Buscar por Datas
        public DataTable BuscarData(DateTime dat1, DateTime dat2)
        {
            DataTable DtResultado = new DataTable("contaLoja");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spmostrarConta";
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlParameter ParTextoBuscar = new SqlParameter();
                ParTextoBuscar.ParameterName = "@dat1";
                ParTextoBuscar.SqlDbType = SqlDbType.VarChar;
                ParTextoBuscar.Size = 150;
                ParTextoBuscar.Value = dat1;
                SqlCmd.Parameters.Add(ParTextoBuscar);

                SqlParameter ParTextoBuscar2 = new SqlParameter();
                ParTextoBuscar2.ParameterName = "@dat2";
                ParTextoBuscar2.SqlDbType = SqlDbType.VarChar;
                ParTextoBuscar2.Size = 150;
                ParTextoBuscar2.Value = dat2;
                SqlCmd.Parameters.Add(ParTextoBuscar2);

                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }
    }
    
}
