﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CamadaDados
{
    public class DEmpresa
    {
        private int _id;
        private string _razao_social;        
        private string _endereco;
        private string _bairro;        
        private string _cidade;
        private string _IE;
        private string _cnpj;
        private string _telefone;
        private string _nome_fantasia;
        private string _numero;
        private string _ccf;
        private string _coo;
        private string _estado;     
        private string _textoBuscar;
        

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Razao_social
        {
            get
            {
                return _razao_social;
            }

            set
            {
                _razao_social = value;
            }
        }

        public string Endereco
        {
            get
            {
                return _endereco;
            }

            set
            {
                _endereco = value;
            }
        }

        public string Bairro
        {
            get
            {
                return _bairro;
            }

            set
            {
                _bairro = value;
            }
        }

        public string Cidade
        {
            get
            {
                return _cidade;
            }

            set
            {
                _cidade = value;
            }
        }

        public string IE
        {
            get
            {
                return _IE;
            }

            set
            {
                _IE = value;
            }
        }

        public string Cnpj
        {
            get
            {
                return _cnpj;
            }

            set
            {
                _cnpj = value;
            }
        }

        public string Telefone
        {
            get
            {
                return _telefone;
            }

            set
            {
                _telefone = value;
            }
        }

       

        public string Nome_fantasia
        {
            get
            {
                return _nome_fantasia;
            }

            set
            {
                _nome_fantasia = value;
            }
        }

        public string Numero
        {
            get
            {
                return _numero;
            }

            set
            {
                _numero = value;
            }
        }

        public string Ccf
        {
            get
            {
                return _ccf;
            }

            set
            {
                _ccf = value;
            }
        }

        public string Coo
        {
            get
            {
                return _coo;
            }

            set
            {
                _coo = value;
            }
        }

        public string Estado
        {
            get
            {
                return _estado;
            }

            set
            {
                _estado = value;
            }
        }

        public string TextoBuscar
        {
            get
            {
                return _textoBuscar;
            }

            set
            {
                _textoBuscar = value;
            }
        }

      

        public DEmpresa()
        {

        }

        public DEmpresa(int id, string razao_social, string endereco, string bairro,
            string cidade, string ie, string cnpj, string telefone, string nome_fantasia, string numero, string ccf, string coo,string estado, string  textoBuscar)
        {
            this.Id = id;
            this.Razao_social = razao_social;
            this.Endereco = endereco;
            this.Bairro = bairro;
            this.Cidade = cidade;
            this.IE = ie;
            this.Cnpj = cnpj;
            this.Telefone = telefone;
            this.Nome_fantasia = nome_fantasia;
            this.Numero = numero;
            this.Ccf = ccf;
            this.Coo = coo;
            this.Estado = estado;
            this.TextoBuscar = textoBuscar;
            
        }

        //métado inserir
        public string Inserir(DEmpresa Empresa)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //codigo
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spinserir_empresa";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParId = new SqlParameter();
                ParId.ParameterName = "@id";
                ParId.SqlDbType = SqlDbType.Int;
                ParId.Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add(ParId);


                SqlParameter ParRazao_social = new SqlParameter();
                ParRazao_social.ParameterName = "@razao_social";
                ParRazao_social.SqlDbType = SqlDbType.VarChar;
                ParRazao_social.Size = 45;
                ParRazao_social.Value = Empresa.Razao_social;
                SqlCmd.Parameters.Add(ParRazao_social);

                SqlParameter ParEndereco = new SqlParameter();
                ParEndereco.ParameterName = "@endereco";
                ParEndereco.SqlDbType = SqlDbType.VarChar;
                ParEndereco.Size = 45;
                ParEndereco.Value = Empresa.Endereco;
                SqlCmd.Parameters.Add(ParEndereco);

                SqlParameter ParBairro = new SqlParameter();
                ParBairro.ParameterName = "@bairro";
                ParBairro.SqlDbType = SqlDbType.VarChar;
                ParBairro.Size = 20;
                ParBairro.Value = Empresa.Bairro;
                SqlCmd.Parameters.Add(ParBairro);

                SqlParameter ParCidade = new SqlParameter();
                ParCidade.ParameterName = "@cidade";
                ParCidade.SqlDbType = SqlDbType.VarChar;
                ParCidade.Size = 20;
                ParCidade.Value = Empresa.Cidade;
                SqlCmd.Parameters.Add(ParCidade);

                SqlParameter ParIe = new SqlParameter();
                ParIe.ParameterName = "@IE";
                ParIe.SqlDbType = SqlDbType.VarChar;
                ParIe.Size = 12;
                ParIe.Value = Empresa.IE;
                SqlCmd.Parameters.Add(ParIe);


                SqlParameter ParCnpj = new SqlParameter();
                ParCnpj.ParameterName = "@CNPJ";
                ParCnpj.SqlDbType = SqlDbType.VarChar;
                ParCnpj.Size = 18;
                ParCnpj.Value = Empresa.Cnpj;
                SqlCmd.Parameters.Add(ParCnpj);           
                

                SqlParameter ParTelefone = new SqlParameter();
                ParTelefone.ParameterName = "@telefone";
                ParTelefone.SqlDbType = SqlDbType.VarChar;
                ParTelefone.Size = 11;
                ParTelefone.Value = Empresa.Telefone;
                SqlCmd.Parameters.Add(ParTelefone);

                SqlParameter ParNomeFantasia = new SqlParameter();
                ParNomeFantasia.ParameterName = "@nome_fantasia";
                ParNomeFantasia.SqlDbType = SqlDbType.VarChar;
                ParNomeFantasia.Size = 50;
                ParNomeFantasia.Value = Empresa.Nome_fantasia;
                SqlCmd.Parameters.Add(ParNomeFantasia);

                SqlParameter ParNumero = new SqlParameter();
                ParNumero.ParameterName = "@numero";
                ParNumero.SqlDbType = SqlDbType.VarChar;
                ParNumero.Size = 6;
                ParNumero.Value = Empresa.Numero;
                SqlCmd.Parameters.Add(ParNumero);

                SqlParameter ParCcf = new SqlParameter();
                ParCcf.ParameterName = "@ccf";
                ParCcf.SqlDbType = SqlDbType.VarChar;
                ParCcf.Size = 10;
                ParCcf.Value = Empresa.Ccf;
                SqlCmd.Parameters.Add(ParCcf);

                SqlParameter ParCoo = new SqlParameter();
                ParCoo.ParameterName = "@coo";
                ParCoo.SqlDbType = SqlDbType.VarChar;
                ParCoo.Size = 8;
                ParCoo.Value = Empresa.Coo;
                SqlCmd.Parameters.Add(ParCoo);

                SqlParameter ParEstado = new SqlParameter();
                ParEstado.ParameterName = "@estado";
                ParEstado.SqlDbType = SqlDbType.VarChar;
                ParEstado.Size = 15;
                ParEstado.Value = Empresa.Estado;
                SqlCmd.Parameters.Add(ParEstado);



                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "Registro não foi Inserido";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;

        }


        //métado editar
        public string Editar(DEmpresa Empresa)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                //codigo
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "speditar_empresa";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParId = new SqlParameter();
                ParId.ParameterName = "@ID";
                ParId.SqlDbType = SqlDbType.Int;
                ParId.Value = Empresa.Id;
                SqlCmd.Parameters.Add(ParId);


                SqlParameter ParRazao_social = new SqlParameter();
                ParRazao_social.ParameterName = "@razao_social";
                ParRazao_social.SqlDbType = SqlDbType.VarChar;
                ParRazao_social.Size = 45;
                ParRazao_social.Value = Empresa.Razao_social;
                SqlCmd.Parameters.Add(ParRazao_social);

                SqlParameter ParEndereco = new SqlParameter();
                ParEndereco.ParameterName = "@endreco";
                ParEndereco.SqlDbType = SqlDbType.VarChar;
                ParEndereco.Size = 45;
                ParEndereco.Value = Empresa.Endereco;
                SqlCmd.Parameters.Add(ParEndereco);

                SqlParameter ParBairro = new SqlParameter();
                ParBairro.ParameterName = "@bairro";
                ParBairro.SqlDbType = SqlDbType.VarChar;
                ParBairro.Size = 20;
                ParBairro.Value = Empresa.Bairro;
                SqlCmd.Parameters.Add(ParBairro);

                SqlParameter ParCidade = new SqlParameter();
                ParCidade.ParameterName = "@cidade";
                ParCidade.SqlDbType = SqlDbType.VarChar;
                ParCidade.Size = 20;
                ParCidade.Value = Empresa.Cidade;
                SqlCmd.Parameters.Add(ParCidade);

                SqlParameter ParIe = new SqlParameter();
                ParIe.ParameterName = "@IE";
                ParIe.SqlDbType = SqlDbType.VarChar;
                ParIe.Size = 12;
                ParIe.Value = Empresa.IE;
                SqlCmd.Parameters.Add(ParIe);


                SqlParameter ParCnpj = new SqlParameter();
                ParCnpj.ParameterName = "@CNPJ";
                ParCnpj.SqlDbType = SqlDbType.VarChar;
                ParCnpj.Size = 18;
                ParCnpj.Value = Empresa.Cnpj;
                SqlCmd.Parameters.Add(ParCnpj);


                SqlParameter ParTelefone = new SqlParameter();
                ParTelefone.ParameterName = "@telefone";
                ParTelefone.SqlDbType = SqlDbType.VarChar;
                ParTelefone.Size = 11;
                ParTelefone.Value = Empresa.Telefone;
                SqlCmd.Parameters.Add(ParTelefone);

                SqlParameter ParNomeFantasia = new SqlParameter();
                ParNomeFantasia.ParameterName = "@nome_fantasia";
                ParNomeFantasia.SqlDbType = SqlDbType.VarChar;
                ParNomeFantasia.Size = 50;
                ParNomeFantasia.Value = Empresa.Nome_fantasia;
                SqlCmd.Parameters.Add(ParNomeFantasia);

                SqlParameter ParNumero = new SqlParameter();
                ParNumero.ParameterName = "@numero";
                ParNumero.SqlDbType = SqlDbType.VarChar;
                ParNumero.Size = 6;
                ParNumero.Value = Empresa.Numero;
                SqlCmd.Parameters.Add(ParNumero);

                SqlParameter ParCcf = new SqlParameter();
                ParCcf.ParameterName = "@ccf";
                ParCcf.SqlDbType = SqlDbType.VarChar;
                ParCcf.Size = 10;
                ParCcf.Value = Empresa.Ccf;
                SqlCmd.Parameters.Add(ParCcf);

                SqlParameter ParCoo = new SqlParameter();
                ParCoo.ParameterName = "@coo";
                ParCoo.SqlDbType = SqlDbType.VarChar;
                ParCoo.Size = 8;
                ParCoo.Value = Empresa.Coo;
                SqlCmd.Parameters.Add(ParCoo);

                SqlParameter ParEstado = new SqlParameter();
                ParEstado.ParameterName = "@estado";
                ParEstado.SqlDbType = SqlDbType.VarChar;
                ParEstado.Size = 15;
                ParEstado.Value = Empresa.Estado;
                SqlCmd.Parameters.Add(ParEstado);



                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "Registro não foi Editado";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;

        }

        //métado excluir
        public string Excluir(DEmpresa Empresa)
        {
            string resp = "";
            SqlConnection SqlCon = new SqlConnection();

            try
            {
                //codigo
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCon.Open();

                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spdeletar_empresa";
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ParId = new SqlParameter();
                ParId.ParameterName = "@id";
                ParId.SqlDbType = SqlDbType.Int;
                ParId.Value = Empresa.Id;
                SqlCmd.Parameters.Add(ParId);

                //Executar o comando

                resp = SqlCmd.ExecuteNonQuery() == 1 ? "OK" : "A exclusão não foi feita";


            }
            catch (Exception ex)
            {
                resp = ex.Message;
            }

            finally
            {
                if (SqlCon.State == ConnectionState.Open) SqlCon.Close();
            }
            return resp;
        }


        //Método Mostrar
        public DataTable Mostrar()
        {
            DataTable DtResultado = new DataTable("empresa");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spmostrar_empresa";
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }

        //Método Buscar Nome
        public DataTable BuscarNome(DEmpresa Empresa)
        {
            DataTable DtResultado = new DataTable("empresa");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spbuscar_empresa_nome";
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlParameter ParTextoBuscar = new SqlParameter();
                ParTextoBuscar.ParameterName = "@textobuscar";
                ParTextoBuscar.SqlDbType = SqlDbType.VarChar;
                ParTextoBuscar.Size = 50;
                ParTextoBuscar.Value = Empresa.TextoBuscar;
                SqlCmd.Parameters.Add(ParTextoBuscar);

                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }

        //Método Buscar Cnpj
        public DataTable BuscarCnpj(DEmpresa Empresa)
        {
            DataTable DtResultado = new DataTable("empresa");
            SqlConnection SqlCon = new SqlConnection();
            try
            {
                SqlCon.ConnectionString = Conexao.Cn;
                SqlCommand SqlCmd = new SqlCommand();
                SqlCmd.Connection = SqlCon;
                SqlCmd.CommandText = "spbuscar_empresa_cnpj";
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlParameter ParTextoBuscar2 = new SqlParameter();
                ParTextoBuscar2.ParameterName = "@textobuscar2";
                ParTextoBuscar2.SqlDbType = SqlDbType.VarChar;
                ParTextoBuscar2.Size = 50;
                ParTextoBuscar2.Value = Empresa.TextoBuscar;
                SqlCmd.Parameters.Add(ParTextoBuscar2);

                SqlDataAdapter sqlDat = new SqlDataAdapter(SqlCmd);
                sqlDat.Fill(DtResultado);

            }
            catch (Exception ex)
            {
                DtResultado = null;
            }
            return DtResultado;

        }

    }  
}
